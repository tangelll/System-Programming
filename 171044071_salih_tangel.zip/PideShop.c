#include <netinet/in.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>
#include <complex.h>
#include <math.h>
#include <sys/time.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <asm-generic/socket.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <semaphore.h>
#define BACKLOG 10  
typedef enum
{
    BEKLIYOR,   
    HAZIRLIYOR, 
    PISIRIYOR,   
    HAZIR,     
    SIPARIS_IPTAL
} OrderStatus;

typedef struct
{
    int id;
    int client_id;
    int x, y;
    OrderStatus status; 
} Order;

typedef struct {
    int id;
    pthread_t thread;
    int is_busy;
    int orders_prepared; 
    Order* current_order;
    Order* before_order;
} Cook;

typedef struct {
    int id;
    pthread_t thread;
    int is_busy;
    int speed;
    int orders_delivered; 
} DeliveryPerson;


typedef struct Node
{
    Order* order;
    struct Node *next;
} Node;

typedef struct
{
    Node *front;
    Node *rear;
    pthread_mutex_t lock;
    pthread_cond_t cond;
} OrderQueue;

// Fırın yapısı
typedef struct
{
    int capacity;
    int current_pides;
    sem_t oven_access; 
    sem_t paddles;     
    pthread_mutex_t lock;
} Oven;

// İşlev prototipleri
void ServerStart(int port, int cook_pool_size, int delivery_pool_size, int delivery_speed);
void *CookFunction(void *arg);
void *Manager(void *arg);
void *DeliverFunction(void *arg);
void OrderProcess(int client_socket);
void OrderEnqueue(OrderQueue* queue, Order* order);
Order* dequeue_order(OrderQueue* queue);
void enqueue_PISIRIYOR_order(OrderQueue* queue, Order* order);
Order* dequeue_PISIRIYOR_order(OrderQueue* queue);
void enqueue_HAZIR_order(OrderQueue* queue, Order* order);
Order* dequeue_HAZIR_order(OrderQueue* queue);
void EventLog(const char *format, ...);
void BestPerformers();




volatile int server_running = 1;
// Global log dosyası
FILE* log_file = NULL;

int server_fd, new_socket; // Sunucu socket dosya tanımlayıcısı
pthread_t manager_thread;
int num_cooks;
int num_delivery_people;
Cook* cooks;
DeliveryPerson* delivery_people;

// İş parçacığı kuyrukları
OrderQueue order_queue; // Gelen siparişlerin kuyruğu
OrderQueue PISIRIYOR_queue; // Pişirilecek siparişlerin kuyruğu
OrderQueue HAZIR_queue; // Pişmiş siparişlerin kuyruğu

// Fırın yapısı
Oven oven;
int PID;
// Shutdown başlatıldı bayrağı
volatile int shutdown_initiated = 0;

void SignalHandler(int signal);

void SignallAll(OrderQueue* queue) {
    pthread_mutex_lock(&queue->lock);
    pthread_cond_broadcast(&queue->cond);
    pthread_mutex_unlock(&queue->lock);
}


void free_order_queue(OrderQueue* queue) {
    Node* current = queue->front;
    while (current != NULL) {
        Node* temp = current;
        current = current->next;
        free(temp->order); // Sipariş belleğini serbest bırak
        free(temp); // Node belleğini serbest bırak
    }
    queue->front = queue->rear = NULL;
}

void KillServer() {
    EventLog("Server is  going to kill");
    server_running = 0;

    // Sunucu soketini kapatın
    close(server_fd);

    // Kuyruktaki tüm thread'leri uyandırın
    SignallAll(&order_queue);
    SignallAll(&PISIRIYOR_queue);
    SignallAll(&HAZIR_queue);

    // Cook thread'lerini sonlandırın
    for (int i = 0; i < num_cooks; i++) {
        pthread_join(cooks[i].thread, NULL);
    }

    // Delivery thread'lerini sonlandırın
    for (int i = 0; i < num_delivery_people; i++) {
        pthread_join(delivery_people[i].thread, NULL);
    }
    // Manager thread'i sonlandırın
    pthread_join(manager_thread, NULL);

    EventLog("All threads terminated");
    BestPerformers();

    // Kuyruklardaki tüm siparişleri serbest bırakma
    free_order_queue(&order_queue);
    free_order_queue(&PISIRIYOR_queue);
    free_order_queue(&HAZIR_queue);

    // Kaynakları serbest bırakma
    free(cooks);
    free(delivery_people);
    pthread_mutex_destroy(&order_queue.lock);
    pthread_cond_destroy(&order_queue.cond);
    pthread_mutex_destroy(&PISIRIYOR_queue.lock);
    pthread_cond_destroy(&PISIRIYOR_queue.cond);
    pthread_mutex_destroy(&HAZIR_queue.lock);
    pthread_cond_destroy(&HAZIR_queue.cond);
    sem_destroy(&oven.oven_access);
    sem_destroy(&oven.paddles);
    pthread_mutex_destroy(&oven.lock);

    // Sunucu kapanırken log dosyasını kapatma
    if (log_file) {
        fclose(log_file);
    }
    exit(0);
}

void SignalHandler(int signum) {
    if (signum == SIGINT || signum == SIGTERM) {
    printf("Server: SIGINT received, sending SIGINT to client...\n");
    kill(PID,SIGINT);
    

        fprintf(stderr, "Received signal %d, initiating shutdown in 10 seconds", signum);
        EventLog("Received signal %d, initiating shutdown", signum);
        if (!shutdown_initiated) {
            shutdown_initiated = 1;
            KillServer();
        }
    }
}


// Basit bir 30x40 matrisin pseudo-inverse hesaplama simülasyonu
double calculate_pseudo_inverse() {
    
      // Zaman ölçümünü başlat
    struct timeval start, end;
    gettimeofday(&start, NULL);

    int m = 30, n = 40;
    double a[m][n], at[n][m], ata[n][n];

    // Matris a'yı rastgele değerlerle doldur
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            a[i][j] = rand() % 100;
        }
    }
    // a'nın transpose'unu hesapla (at)
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            at[j][i] = a[i][j];
        }
    }

    // at * a'yı hesapla (ata)
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            ata[i][j] = 0;
            for (int k = 0; k < m; k++) {
                ata[i][j] += at[i][k] * a[k][j];
            }
        }
    }

    // ata'nın pseudo-inverse'ini hesapla (atainv)
    // Burada sadece bir simülasyon yapıyoruz, bu yüzden inversini almak için basit bir yaklaşım kullanıyoruz
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (i == j) {
                //atainv[i][j] = 1.0 / (ata[i][j] + 1e-9);  // Basit invers
            } else {
                //atainv[i][j] = 0;
            }
        }
    }

    // Zaman ölçümünü bitir
    gettimeofday(&end, NULL);

    // Hesaplama süresini belirle
    double elapsed_time = (end.tv_sec - start.tv_sec) + (end.tv_usec - start.tv_usec) / 1e6;

    return elapsed_time;
}

// Sunucuyu başlatma ve iş parçacıklarını oluşturma
void ServerStart(int port, int cook_pool_size, int delivery_pool_size, int delivery_speed) {
    signal(SIGINT, SignalHandler);
    signal(SIGTERM, SignalHandler);

    int opt = 1; 
    struct sockaddr_in address;
    int addrlen = sizeof(address);

    // Log dosyasını açma
    log_file = fopen("pideshop.log", "w+");
    if (log_file == NULL) {
        perror("Log file opening failed");
        exit(EXIT_FAILURE);
    }
    EventLog("PideShop server started");

    // Kuyruk başlangıç durumu
    order_queue.front = order_queue.rear = NULL;
    pthread_mutex_init(&order_queue.lock, NULL);
    pthread_cond_init(&order_queue.cond, NULL);

    PISIRIYOR_queue.front = PISIRIYOR_queue.rear = NULL;
    pthread_mutex_init(&PISIRIYOR_queue.lock, NULL);
    pthread_cond_init(&PISIRIYOR_queue.cond, NULL);

    HAZIR_queue.front = HAZIR_queue.rear = NULL;
    pthread_mutex_init(&HAZIR_queue.lock, NULL);
    pthread_cond_init(&HAZIR_queue.cond, NULL);

    // İş parçacığı havuzlarını oluşturma
    num_cooks = cook_pool_size;
    num_delivery_people = delivery_pool_size;
    cooks = (Cook*)malloc(num_cooks * sizeof(Cook));
    delivery_people = (DeliveryPerson*)malloc(num_delivery_people * sizeof(DeliveryPerson));

    for (int i = 0; i < num_cooks; i++) {
        cooks[i].id = i + 1;
        cooks[i].is_busy = 0;
        cooks[i].orders_prepared = 0;
        cooks[i].current_order = NULL;
        cooks[i].before_order = NULL;
        pthread_create(&cooks[i].thread, NULL, CookFunction, &cooks[i]);
    }

    for (int i = 0; i < num_delivery_people; i++) {
        delivery_people[i].id = i + 1;
        delivery_people[i].is_busy = 0;
        delivery_people[i].speed = delivery_speed;
        delivery_people[i].orders_delivered = 0;
        pthread_create(&delivery_people[i].thread, NULL, DeliverFunction, &delivery_people[i]);
    }

    // Yönetici iş parçacığını başlatma
    pthread_create(&manager_thread, NULL, Manager, NULL);

    // Fırın başlangıç durumu
    oven.capacity = 6; // Fırın kapasitesi
    oven.current_pides = 0;
    sem_init(&oven.oven_access, 0, 2); // Fırına 2 erişim noktası
    sem_init(&oven.paddles, 0, 3); // 3 kürek var
    pthread_mutex_init(&oven.lock, NULL);

    // Socket oluşturma
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

        // Forcefully attaching socket to the port
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt)))
    {
        perror("setsockopt");
        exit(EXIT_FAILURE);
    }
    // Adresi ve portu ayarlama
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(port);

    // Adres ve portu bağlama
    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("bind failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    // Dinlemeye başlama
    if (listen(server_fd, BACKLOG) < 0) {
        perror("listen");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    EventLog("PideShop server is listening on port %d", port);
    EventLog("Cook thread pool size: %d", cook_pool_size);
    EventLog("Delivery thread pool size: %d", delivery_pool_size);
    EventLog("Delivery speed: %d m/min", delivery_speed);

    // Sunucu çalışma döngüsü
    while (server_running) {
        new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen);
        if (new_socket < 0) {
            if (server_running) {
                perror("accept");
            }
            break;
        }

        EventLog("New connection established from client");

        // Siparişi işleme
        OrderProcess(new_socket);

        // Bağlantıyı kapatma
        close(new_socket);
    }

    KillServer(); // Sunucu durdurma işlemi
}

// Loglama işlevi
void EventLog(const char* format, ...) {
    if (log_file || new_socket > 0) {
        va_list args;
        va_start(args, format);

        // Zaman damgasını ekle
        time_t now = time(NULL);
        struct tm* t = localtime(&now);
        char log_msg[1024];
        int len = snprintf(log_msg, sizeof(log_msg), "%04d-%02d-%02d %02d:%02d:%02d: ",
                           t->tm_year + 1900, t->tm_mon + 1, t->tm_mday,
                           t->tm_hour, t->tm_min, t->tm_sec);

        // Log mesajını ekle
        vsnprintf(log_msg + len, sizeof(log_msg) - len, format, args);
        strncat(log_msg, "\n", sizeof(log_msg) - strlen(log_msg) - 1);

        if (log_file) {
            fprintf(log_file, "%s", log_msg);
            fflush(log_file); // Log mesajını hemen dosyaya yaz
        }

        if (new_socket > 0) {
            send(new_socket, log_msg, strlen(log_msg), 0);
        }

        va_end(args);
    
    }
}
void BestPerformers() {
    int max_orders_prepared = 0;
    int best_cook_id = 0;
    for (int i = 0; i < num_cooks; i++) {
        if (cooks[i].orders_prepared > max_orders_prepared) {
            max_orders_prepared = cooks[i].orders_prepared;
            best_cook_id = cooks[i].id;
        }
    }

    int max_orders_delivered = 0;
    int best_delivery_person_id = 0;
    for (int i = 0; i < num_delivery_people; i++) {
        if (delivery_people[i].orders_delivered > max_orders_delivered) {
            max_orders_delivered = delivery_people[i].orders_delivered;
            best_delivery_person_id = delivery_people[i].id;
        }
    }

    // En verimli aşçı ve teslimat personelini log dosyasına ve terminale yazdır
    printf("Best Cook of mount %d and Moto %d\n", best_cook_id, best_delivery_person_id);
    EventLog("Thanks Cook %d and Moto %d", best_cook_id, best_delivery_person_id);
}

// Aşçı iş parçacığı fonksiyonu
void* CookFunction(void* arg) {
    Cook* cook = (Cook*)arg;
    double preparation_time;
    preparation_time = calculate_pseudo_inverse();
    while (server_running) {
        // Yeni bir sipariş al ve hazırlamaya başla
        pthread_mutex_lock(&PISIRIYOR_queue.lock);
        Order* current_order = NULL;
        while (server_running && PISIRIYOR_queue.front == NULL) {
            pthread_cond_wait(&PISIRIYOR_queue.cond, &PISIRIYOR_queue.lock);
        }
        if (server_running && PISIRIYOR_queue.front != NULL) {
            current_order = dequeue_PISIRIYOR_order(&PISIRIYOR_queue);
        }
        pthread_mutex_unlock(&PISIRIYOR_queue.lock);

        // İlk yarıyı hazırlama
        if (current_order != NULL) {
            current_order->status = HAZIRLIYOR;
            EventLog("Cook %d is HAZIRLIYOR Order %d", cook->id, current_order->id);
            preparation_time = preparation_time / 2.0;
            sleep(preparation_time);
            EventLog("Cook %d has HAZIRLADI half of Order %d in %f seconds", cook->id, current_order->id, preparation_time);
        }

        // Fırında önceki sipariş varsa çıkar ve teslimat kuyruğuna ekle
        if (cook->before_order != NULL) {
            // Fırında pişen siparişin pişme süresi doldu
            sem_wait(&oven.oven_access);
            sem_wait(&oven.paddles);

            pthread_mutex_lock(&oven.lock);
            if (oven.current_pides > 0) {
                oven.current_pides--;
                cook->orders_prepared++;
                EventLog("Cook %d has KALDIRDI Order %d from the oven (current pides in oven: %d)", cook->id, cook->before_order->id, oven.current_pides);
                cook->before_order->status = HAZIR; // Sipariş teslimat için hazır
            }
            pthread_mutex_unlock(&oven.lock);

            sem_post(&oven.paddles);
            sem_post(&oven.oven_access);

            // Pişmiş siparişi pişmiş sipariş kuyruğuna ekle
            pthread_mutex_lock(&HAZIR_queue.lock);
            enqueue_HAZIR_order(&HAZIR_queue, cook->before_order);
            pthread_cond_signal(&HAZIR_queue.cond);
            pthread_mutex_unlock(&HAZIR_queue.lock);

            cook->before_order = NULL; // Önceki siparişi sıfırla
        }

        // İkinci yarıyı hazırlama
        if (current_order != NULL) {
            preparation_time = preparation_time / 2.0;
            sleep(preparation_time);
            EventLog("Cook: %d  siparis nolu: %d siparisi  %f saniyede bitirdi.", cook->id, current_order->id, preparation_time);

            // Pideyi fırına koyma
            sem_wait(&oven.oven_access);
            sem_wait(&oven.paddles);

            pthread_mutex_lock(&oven.lock);
            if (oven.current_pides < oven.capacity) {
                oven.current_pides++;
                EventLog("Cook: %d siparis nolu:  %d siparisi firina yerlestiriyor.(current pides in oven: %d)", cook->id, current_order->id, oven.current_pides);
                current_order->status = PISIRIYOR; // Sipariş pişiyor
            }
            pthread_mutex_unlock(&oven.lock);

            sem_post(&oven.paddles);
            sem_post(&oven.oven_access);

            // Yeni pişen siparişi before_order olarak ayarla
            cook->before_order = current_order;

            // Yeni sipariş için aşçıyı müsait yap
            cook->is_busy = 0;
        }

        // Yeni sipariş olmadığında uyku durumu
        if (current_order == NULL) {
            usleep(100000); // 0.1 saniye bekle
        }

        // Sunucu durumu kontrolü
        if (!server_running) break;
    }
    return NULL;
}

// Yönetici iş parçacığı fonksiyonu
void* Manager(void* arg) {
    while (server_running) {
        // Sipariş kuyruğundan bir sipariş al
        pthread_mutex_lock(&order_queue.lock);
        while (server_running && order_queue.front == NULL) {
            pthread_cond_wait(&order_queue.cond, &order_queue.lock);
        }
        Order* order = NULL;
        if (server_running && order_queue.front != NULL) {
            order = dequeue_order(&order_queue);
        }
        pthread_mutex_unlock(&order_queue.lock);

        if (order != NULL) {
            // Siparişi pişirilecek sipariş kuyruğuna ekle
            pthread_mutex_lock(&PISIRIYOR_queue.lock);
            enqueue_PISIRIYOR_order(&PISIRIYOR_queue, order);
            pthread_cond_signal(&PISIRIYOR_queue.cond);
            pthread_mutex_unlock(&PISIRIYOR_queue.lock);

            // Aşçıları bilgilendir
            for (int i = 0; i < num_cooks; i++) {
                if (!cooks[i].is_busy) {
                    cooks[i].is_busy = 1;
                    cooks[i].current_order = order; // Aşçının şu anki siparişini ayarla
                    EventLog("Manager assigned Order %d to Cook %d", order->id, cooks[i].id);
                    break;
                }
            }
        }

        // Teslimat işlevi için kuyruğu kontrol et
        pthread_mutex_lock(&HAZIR_queue.lock);
        pthread_cond_signal(&HAZIR_queue.cond);
        pthread_mutex_unlock(&HAZIR_queue.lock);

        if (!server_running) break; // Sunucu durumu kontrolü
    }
    return NULL;
}

void* DeliverFunction(void* arg) {
    DeliveryPerson* delivery_person = (DeliveryPerson*)arg;
    int delivery_time;
    Order* bag[3]; // Teslimat çantasındaki siparişler
    int current_bag = 0; // Çantadaki mevcut sipariş sayısı

    while (server_running) {
        pthread_mutex_lock(&HAZIR_queue.lock);
        while (server_running && HAZIR_queue.front == NULL) {
            pthread_cond_wait(&HAZIR_queue.cond, &HAZIR_queue.lock);
        }
        Order* order = NULL;
        if (server_running && HAZIR_queue.front != NULL) {
            order = dequeue_HAZIR_order(&HAZIR_queue);
        }
        pthread_mutex_unlock(&HAZIR_queue.lock);
        
        if (order != NULL) {
            bag[current_bag++] = order; // Siparişi çantaya ekle
            EventLog("Delivery Person %d has added Order %d to the bag (current bag: %d)", delivery_person->id, order->id, current_bag);

            if (current_bag == 3) { // Çanta doluysa teslimata çık
                EventLog("Delivery Person %d is delivering orders with a full bag", delivery_person->id);
                for (int i = 0; i < 3; i++) {
                    order = bag[i];
                    if (order) {
                        delivery_time = (abs(order->x) + abs(order->y)) / delivery_person->speed;
                        sleep(delivery_time); // Teslimat süresi simülasyonu
                        delivery_person->orders_delivered++;
                        EventLog("Delivery Person %d has delivered Order %d", delivery_person->id, order->id);
                        free(order); // Sipariş belleğini serbest bırak
                    }
                }
                current_bag = 0; // Çantayı boşalt
            }
        } else {
            // Eğer kuyruk boşsa ve çantada sipariş varsa teslimata çık
            if (current_bag > 0) {
                EventLog("Delivery Person %d is delivering remaining orders in the bag", delivery_person->id);
                for (int i = 0; i < current_bag; i++) {
                    order = bag[i];
                    if (order) {
                        delivery_time = (abs(order->x) + abs(order->y)) / delivery_person->speed;
                        sleep(delivery_time); // Teslimat süresi simülasyonu
                        delivery_person->orders_delivered++;
                        EventLog("Delivery Person %d has delivered Order %d", delivery_person->id, order->id);
                        free(order); // Sipariş belleğini serbest bırak
                    }
                }
                current_bag = 0; // Çantayı boşalt
            }
        }

        if (!server_running) break;
    }
    return NULL;
}



void OrderProcess(int client_socket) {
    char buffer[1024] = {0};
    int bytes_read = read(client_socket, buffer, sizeof(buffer) - 1);
    
    if (bytes_read > 0) {
        EventLog("Received order: %s", buffer);

        // Siparişi order kuyruğuna ekle
        Order* order = (Order*)malloc(sizeof(Order));
        sscanf(buffer, "Client ID: %d; Order Number: %d; Location: (%d, %d); PID :%d",
               &order->client_id, &order->id, &order->x, &order->y, &PID);
        order->status = BEKLIYOR; // Sipariş durumu başlangıçta bekliyor

        pthread_mutex_lock(&order_queue.lock);
        OrderEnqueue(&order_queue, order);
        pthread_cond_signal(&order_queue.cond);
        pthread_mutex_unlock(&order_queue.lock);
    }
}

void OrderEnqueue(OrderQueue* queue, Order* order) {
    Node* new_node = (Node*)malloc(sizeof(Node));
    new_node->order = order;
    new_node->next = NULL;

    if (queue->rear == NULL) {
        queue->front = queue->rear = new_node;
    } else {
        queue->rear->next = new_node;
        queue->rear = new_node;
    }
    EventLog("Order enqueued: Order Number: %d", order->id);
}

Order* dequeue_order(OrderQueue* queue) {
    if (queue->front == NULL) {
        return NULL;
    }

    Node* temp = queue->front;
    Order* order = temp->order;
    queue->front = queue->front->next;

    if (queue->front == NULL) {
        queue->rear = NULL;
    }

    free(temp); // Node belleğini serbest bırak
    return order;
}


// Pişirilecek sipariş kuyruğuna ekleme (PISIRIYOR Queue)
void enqueue_PISIRIYOR_order(OrderQueue* queue, Order* order) {
    Node* new_node = (Node*)malloc(sizeof(Node));
    new_node->order = order;
    new_node->next = NULL;

    if (queue->rear == NULL) {
        queue->front = queue->rear = new_node;
    } else {
        queue->rear->next = new_node;
        queue->rear = new_node;
    }
    EventLog("Order HAZIR for PISIRIYOR: Order Number: %d", order->id);
}

// Pişmiş sipariş kuyruğuna ekleme (HAZIR Queue)
void enqueue_HAZIR_order(OrderQueue* queue, Order* order) {
    Node* new_node = (Node*)malloc(sizeof(Node));
    new_node->order = order;
    new_node->next = NULL;

    if (queue->rear == NULL) {
        queue->front = queue->rear = new_node;
    } else {
        queue->rear->next = new_node;
        queue->rear = new_node;
    }
    EventLog("Order HAZIR for delivery: Order Number: %d", order->id);
}

Order* dequeue_PISIRIYOR_order(OrderQueue* queue) {
    if (queue->front == NULL) {
        return NULL;
    }

    Node* temp = queue->front;
    Order* order = temp->order;
    queue->front = queue->front->next;

    if (queue->front == NULL) {
        queue->rear = NULL;
    }

    free(temp); // Node belleğini serbest bırak
    return order;
}

Order* dequeue_HAZIR_order(OrderQueue* queue) {
    if (queue->front == NULL) {
        return NULL;
    }

    Node* temp = queue->front;
    Order* order = temp->order;
    queue->front = queue->front->next;

    if (queue->front == NULL) {
        queue->rear = NULL;
    }

    free(temp); // Node belleğini serbest bırak
    return order;
}


// Ana fonksiyon, sunucuyu başlatır ve gerekli parametreleri alır.
int main(int argc, char *argv[]) {
    if (argc != 5) {
        fprintf(stderr, "Usage: %s [portnumber] [CookthreadPoolSize] [DeliveryPoolSize] [k]\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    int port = atoi(argv[1]);
    int cook_pool_size = atoi(argv[2]);
    int delivery_pool_size = atoi(argv[3]);
    int delivery_speed = atoi(argv[4]);

    // Sunucuyu başlatma ve iş parçacıklarını oluşturma
    ServerStart(port, cook_pool_size, delivery_pool_size, delivery_speed);

    return 0;
}

