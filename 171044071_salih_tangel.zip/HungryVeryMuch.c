#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <semaphore.h>
typedef enum
{
    BEKLIYOR,   
    HAZIRLIYOR, 
    PISIRIYOR,   
    HAZIR,     
    SIPARIS_IPTAL
} OrderStatus;

typedef struct
{
    int id;
    int client_id;
    int x, y;
    OrderStatus status; 
} Order;

typedef struct {
    int id;
    pthread_t thread;
    int is_busy;
    int orders_prepared; 
    Order* current_order;
    Order* before_order;
} Cook;

typedef struct {
    int id;
    pthread_t thread;
    int is_busy;
    int speed;
    int orders_delivered; 
} DeliveryPerson;


typedef struct Node
{
    Order* order;
    struct Node *next;
} Node;

typedef struct
{
    Node *front;
    Node *rear;
    pthread_mutex_t lock;
    pthread_cond_t cond;
} OrderQueue;

// Fırın yapısı
typedef struct
{
    int capacity;
    int current_pides;
    sem_t oven_access; 
    sem_t paddles;     
    pthread_mutex_t lock;
} Oven;

// İşlev prototipleri
void ServerStart(int port, int cook_pool_size, int delivery_pool_size, int delivery_speed);
void *CookFunction(void *arg);
void *Manager(void *arg);
void *DeliverFunction(void *arg);
void OrderProcess(int client_socket);
void OrderEnqueue(OrderQueue* queue, Order* order);
Order* dequeue_order(OrderQueue* queue);
void enqueue_PISIRIYOR_order(OrderQueue* queue, Order* order);
Order* dequeue_PISIRIYOR_order(OrderQueue* queue);
void enqueue_HAZIR_order(OrderQueue* queue, Order* order);
Order* dequeue_HAZIR_order(OrderQueue* queue);
void EventLog(const char *format, ...);
void BestPerformers();

int sock = 0;
int stop =0;

void handle_sigint(int sig) {
    printf("Client: SIGINT received, cleaning up and exiting...\n");
     if (sock > 0) {
        close(sock);
    }
    stop =1;
}


void LogsRead() {
    char buffer[1024] = {0};
    fd_set read_fds;
    int activity;
    struct timeval timeout;

    while (1) {
        FD_ZERO(&read_fds);
        FD_SET(sock, &read_fds);

        timeout.tv_sec = 5; // 5 saniye timeout
        timeout.tv_usec = 0;

        activity = select(sock + 1, &read_fds, NULL, NULL, &timeout);

        if (activity < 0) {
            perror("select error");
            return;
        }

        if (activity == 0) {
            // Timeout
            continue;
        }

        if (FD_ISSET(sock, &read_fds)) {
            int bytes_read = read(sock, buffer, sizeof(buffer));
            if (bytes_read > 0) {
                buffer[bytes_read] = '\0';
                printf("%s", buffer);
            } else if (bytes_read == 0) {
                // Connection closed by server
                printf("Server closed connection\n");
                close(sock);
                return;
            }
        }
    }
}

void ServerConnect(const char* server_ip, int port, int client_id, int p, int q, int PID);
const char* server_ip;
int port;
int numberOfClients;
int p;
int q;

void* client_handler(void* arg) {
    // Her bir müşteri için sunucuya bağlanma
    for (int i = 0; i < numberOfClients && stop != 1; i++) {
        printf("Client %d connecting to server...\n", i + 1);
        int PID = getpid();
        ServerConnect(server_ip, port, i + 1, p, q, PID);
    }

    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc != 6) {
        fprintf(stderr, "Usage: %s [server_ip] [portnumber] [numberOfClients] [p] [q]\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    signal(SIGINT, handle_sigint);
    server_ip = argv[1];
    port = atoi(argv[2]);
    numberOfClients = atoi(argv[3]);
    p = atoi(argv[4]);
    q = atoi(argv[5]);

    srand(time(NULL));  // Rastgele konumlar için seed

    pthread_t client_thread;
    if (pthread_create(&client_thread, NULL, client_handler, NULL) < 0) {
        perror("could not create thread");
        return 1;
    }

    if (pthread_join(client_thread, NULL)) {
        perror("could not join thread");
        return 1;
    }

    return 0;
}

void ServerConnect(const char* server_ip, int port, int client_id, int p, int q,int PID) {
    struct sockaddr_in serv_addr;

    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        printf("Socket creation error \n");
        return;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(port);

    if (inet_pton(AF_INET, server_ip, &serv_addr.sin_addr) <= 0) {
        printf("Invalid address/ Address not supported \n");
        return;
    }

    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        printf("Connection Failed \n");
        return;
    }

    printf("Connected to server\n");

    printf("Connected to log server\n");
    
    // Rastgele konum oluşturma
    int x = rand() % p;
    int y = rand() % q;

    // Sipariş mesajı oluşturma
    char order_msg[256];
    snprintf(order_msg, sizeof(order_msg), "Client ID: %d; Order Number: %d; Location: (%d, %d); PID :%d ", client_id, client_id, x, y, PID);

    // Siparişi sunucuya gönderme
    send(sock, order_msg, strlen(order_msg), 0);
    printf("Order sent: %s\n", order_msg);
    LogsRead();
    // Bağlantıyı kapatma
    close(sock);
    printf("Connection closed\n");
}




