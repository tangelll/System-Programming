#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <stdatomic.h>

#define MAX_PICKUP_SPOTS 4
#define MAX_AUTOMOBILE_SPOTS 8
#define MAX_VEHICLES 50

typedef struct {
    int id;
    char type; // 'C' for car, 'P' for pickup
} Vehicle;

// Global counters
atomic_int freeAutomobileSpots = ATOMIC_VAR_INIT(MAX_AUTOMOBILE_SPOTS);
atomic_int freePickupSpots = ATOMIC_VAR_INIT(MAX_PICKUP_SPOTS);
atomic_int vehiclesLeftToPark = ATOMIC_VAR_INIT(MAX_VEHICLES);
pthread_mutex_t vehicleLock = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;

// Semaphores
sem_t newPickup, inChargeforPickup, newAutomobile, inChargeforAutomobile;

// Initialize semaphores
void initializeSemaphores() {
    sem_init(&newPickup, 0, 0);
    sem_init(&inChargeforPickup, 0, 0);
    sem_init(&newAutomobile, 0, 0);
    sem_init(&inChargeforAutomobile, 0, 0);
}

// Thread function for car owners
void* carOwner(void* vehicle) {
    Vehicle* v = (Vehicle*) vehicle;
    pthread_mutex_lock(&vehicleLock);

    if (v->type == 'C') {
        if (freeAutomobileSpots > 0) {
            freeAutomobileSpots--;
            printf("Car %d parked. Remaining spots for car: %d\n", v->id, freeAutomobileSpots);
            sem_post(&newAutomobile);
        } else {
            printf("No space for car %d\n", v->id);
        }
    } else if (v->type == 'P') {
        if (freePickupSpots > 0) {
            freePickupSpots--;
            printf("Pickup %d parked. Remaining spots for pickups: %d\n", v->id, freePickupSpots);
            sem_post(&newPickup);
        } else {
            printf("No space for pickup %d\n", v->id);
        }
    }

    vehiclesLeftToPark--;  // Decrement the number of vehicles left to park
    if (vehiclesLeftToPark == 0) {
        pthread_cond_signal(&cond);  // Signal the condition variable to start attendant processing
    }

    pthread_mutex_unlock(&vehicleLock);
    return NULL;
}

// Thread function for attendants
void* carAttendant(void* arg) {
    pthread_mutex_lock(&vehicleLock);
    while (vehiclesLeftToPark > 0) {
        pthread_cond_wait(&cond, &vehicleLock);  // Wait until all car owners are done
    }
    pthread_mutex_unlock(&vehicleLock);

    while (freeAutomobileSpots < MAX_AUTOMOBILE_SPOTS || freePickupSpots < MAX_PICKUP_SPOTS) {
        if (sem_trywait(&newAutomobile) == 0) {
            printf("Car attended and parked to a permanent spot.\n");
            freeAutomobileSpots++;
            sem_post(&inChargeforAutomobile);
        }
        if (sem_trywait(&newPickup) == 0) {
            printf("Pickup attended and parked to a permanent spot.\n");
            freePickupSpots++;
            sem_post(&inChargeforPickup);
        }
    }
    printf("All parking spots are full. Exiting attendant loop.\n");
    return NULL;
}

int main() {
    if (MAX_VEHICLES < 1) {
        printf("Please enter a valid number of max vehicles.\n");
        return 1;
    }

    srand(time(NULL));  // For random number generation
    initializeSemaphores();

    pthread_t threads[MAX_VEHICLES];
    Vehicle vehicles[MAX_VEHICLES];

    // Create threads for vehicles
    for (int i = 0; i < MAX_VEHICLES; i++) {
        int num = rand(); // Generate random number
        if (num % 2 == 0) {
            vehicles[i].type = 'P'; // Even number: Pickup
        } else {
            vehicles[i].type = 'C'; // Odd number: Car
        }
        vehicles[i].id = i + 1;
        pthread_create(&threads[i], NULL, carOwner, &vehicles[i]);
    }

    // Create thread for attendant
    pthread_t attendantThread;
    pthread_create(&attendantThread, NULL, carAttendant, NULL);

    // Wait for all threads to finish
    for (int i = 0; i < MAX_VEHICLES; i++) {
        pthread_join(threads[i], NULL);
    }
    pthread_join(attendantThread, NULL);

    // Destroy semaphores
    sem_destroy(&newPickup);
    sem_destroy(&inChargeforPickup);
    sem_destroy(&newAutomobile);
    sem_destroy(&inChargeforAutomobile);

    pthread_mutex_destroy(&vehicleLock);
    pthread_cond_destroy(&cond);

    return 0;
}
