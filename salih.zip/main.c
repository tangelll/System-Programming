#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <signal.h>
// Define buffer, flags, mutex, and condition variables
#define BUFFER_SIZE 10
char buffer[BUFFER_SIZE][PATH_MAX];
int buffer_count = 0;
int done = 0;
int interrupted = 0;

pthread_mutex_t mutex;
pthread_cond_t cond_full;
pthread_cond_t cond_empty;
void sigint_handler(int signum);
void* manager_thread(void* arg);
void* worker_thread(void* arg);

int main(int argc, char *argv[]) {
    sleep(1);
    // Parse command-line arguments
    if (argc != 5) {
        fprintf(stderr, "Usage: %s <buffer_size> <num_workers> <src_dir> <dst_dir>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

        // Set up SIGINT handler
    struct sigaction sa;
    sa.sa_handler = sigint_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sigaction(SIGINT, &sa, NULL);

    int buffer_size = atoi(argv[1]);
    int num_workers = atoi(argv[2]);
    char *src_dir = argv[3];
    char *dst_dir = argv[4];

    // Initialize mutex and condition variables
    pthread_mutex_init(&mutex, NULL);
    pthread_cond_init(&cond_full, NULL);
    pthread_cond_init(&cond_empty, NULL);

    // Create manager thread
    pthread_t manager;
    pthread_create(&manager, NULL, manager_thread, (void *)argv);

    // Create worker threads
    pthread_t workers[num_workers];
    for (int i = 0; i < num_workers; i++) {
        pthread_create(&workers[i], NULL, worker_thread, NULL);
    }

    // Wait for threads to finish
    pthread_join(manager, NULL);
    for (int i = 0; i < num_workers; i++) {
        pthread_join(workers[i], NULL);
    }

    // Cleanup
    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&cond_full);
    pthread_cond_destroy(&cond_empty);

    return 0;
}

void sigint_handler(int signum) {
    // Set interrupted flag to indicate SIGINT was received
    interrupted = 1;
    // Signal all threads to wake up and check the flag

    printf("Sigint received\n");
    pthread_mutex_lock(&mutex);
    done = 1;
    pthread_cond_broadcast(&cond_full);
    pthread_cond_broadcast(&cond_empty);
    pthread_mutex_unlock(&mutex);
}

void* manager_thread(void* arg) {
    // Read source and destination directories
    char **args = (char **)arg;
    char *src_dir = args[3];
    char *dst_dir = args[4];
    DIR *src = opendir(src_dir);
    if (src == NULL) {
        perror("opendir");
        exit(EXIT_FAILURE);
    }

    struct dirent *entry;
    while ((entry = readdir(src)) != NULL) {
        // Skip '.' and '..'
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
            continue;
        }

        char src_path[PATH_MAX];
        char dst_path[PATH_MAX];
        snprintf(src_path, PATH_MAX, "%s/%s", src_dir, entry->d_name);
        snprintf(dst_path, PATH_MAX, "%s/%s", dst_dir, entry->d_name);

        // Open source file for reading
        int src_fd = open(src_path, O_RDONLY);
        if (src_fd < 0) {
            perror("open src");
            continue;
        }

        // Open destination file for writing (truncate if exists)
        int dst_fd = open(dst_path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (dst_fd < 0) {
            perror("open dst");
            close(src_fd);
            continue;
        }

        // Add file descriptors to buffer
        pthread_mutex_lock(&mutex);
        while (buffer_count == BUFFER_SIZE) {
            pthread_cond_wait(&cond_empty, &mutex);
        }
        snprintf(buffer[buffer_count], PATH_MAX, "%d:%d", src_fd, dst_fd);
        buffer_count++;
        pthread_cond_signal(&cond_full);
        pthread_mutex_unlock(&mutex);
    }

    // Signal completion
    pthread_mutex_lock(&mutex);
    done = 1;
    pthread_cond_broadcast(&cond_full);
    pthread_mutex_unlock(&mutex);

    closedir(src);
    return NULL;
}

void* worker_thread(void* arg) {
    while (1) {
        // Read from buffer
        pthread_mutex_lock(&mutex);
        while (buffer_count == 0 && !done) {
            pthread_cond_wait(&cond_full, &mutex);
        }
        if (buffer_count == 0 && done) {
            pthread_mutex_unlock(&mutex);
            break;
        }
        char entry[PATH_MAX];
        strcpy(entry, buffer[--buffer_count]);
        pthread_cond_signal(&cond_empty);
        pthread_mutex_unlock(&mutex);

        // Parse file descriptors
        int src_fd, dst_fd;
        sscanf(entry, "%d:%d", &src_fd, &dst_fd);

        // Copy file content
        char buf[4096];
        ssize_t bytes;
        while ((bytes = read(src_fd, buf, sizeof(buf))) > 0) {
            write(dst_fd, buf, bytes);
        }

        // Close file descriptors
        close(src_fd);
        close(dst_fd);

        // Report completion status
        printf("File copied: %s\n", entry);
    }
    return NULL;
}
