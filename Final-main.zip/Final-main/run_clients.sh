#!/bin/bash

# 10 tane client bağlantısı aç
for ((i=1; i<=10; i++))
do
  clientdir="clientdir$i"
  ./client "$clientdir" $1 192.168.1.147 &
done

wait

