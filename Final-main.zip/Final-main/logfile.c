#include <stdio.h>
#include <time.h>

int main() {
    // Get the current time
    time_t current_time = time(NULL);

    // Convert the time to a local time string
    char time_string[100];
    strftime(time_string, sizeof(time_string), "%Y-%m-%d %H:%M:%S", localtime(&current_time));

    // Print the timestamp
    printf("Current time: %s\n", time_string);

    return 0;
}
s