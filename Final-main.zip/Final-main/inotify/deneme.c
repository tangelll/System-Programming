#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>
#include <time.h>

typedef struct {
    char name[256];
    time_t lastModified;
    off_t size;
} FileInfo;

void checkDirectory(const char* folderPath, FileInfo** prevFiles, int* prevCount) {
    struct dirent** curEntries;
    int curCount;

    curCount = scandir(folderPath, &curEntries, NULL, alphasort);
    if (curCount == -1) {
        perror("Failed to scan directory");
        exit(EXIT_FAILURE);
    }

    // Yeni eklenen dosyaları kontrol et
    for (int i = 0; i < curCount; ++i) {
        struct dirent* curEntry = curEntries[i];

        if (curEntry->d_type == DT_REG) { // Sadece dosyalara odaklanır
            int isNew = 1;
            for (int j = 0; j < *prevCount; ++j) {
                FileInfo* prevFile = &((*prevFiles)[j]);

                if (strcmp(curEntry->d_name, prevFile->name) == 0) {
                    isNew = 0;

                    struct stat curStat;
                    char curFilePath[512];
                    sprintf(curFilePath, "%s/%s", folderPath, curEntry->d_name);

                    if (stat(curFilePath, &curStat) == 0) {
                        // Dosyanın son değiştirilme zamanı veya boyutu değişti mi?
                        if (curStat.st_mtime != prevFile->lastModified || curStat.st_size != prevFile->size) {
                            printf("File modified: %s\n", curEntry->d_name);
                            // Son değiştirilme zamanını ve boyutunu güncelle
                            prevFile->lastModified = curStat.st_mtime;
                            prevFile->size = curStat.st_size;
                        }
                    }
                    break;
                }
            }

            if (isNew) {
                printf("New file added: %s\n", curEntry->d_name);

                // Yeni dosya için FileInfo oluştur ve kaydet
                FileInfo newFile;
                strcpy(newFile.name, curEntry->d_name);
                struct stat curStat;
                char curFilePath[512];
                sprintf(curFilePath, "%s/%s", folderPath, curEntry->d_name);

                if (stat(curFilePath, &curStat) == 0) {
                    newFile.lastModified = curStat.st_mtime;
                    newFile.size = curStat.st_size;
                }
                *prevCount += 1;
                *prevFiles = (FileInfo*)realloc(*prevFiles, (*prevCount) * sizeof(FileInfo));
                (*prevFiles)[*prevCount - 1] = newFile;
            }
        }
    }

    // Silinen dosyaları kontrol et
    for (int i = 0; i < *prevCount; ++i) {
        FileInfo* prevFile = &((*prevFiles)[i]);
        int isDeleted = 1;

        for (int j = 0; j < curCount; ++j) {
            struct dirent* curEntry = curEntries[j];

            if (strcmp(curEntry->d_name, prevFile->name) == 0) {
                isDeleted = 0;
                break;
            }
        }

        if (isDeleted) {
            printf("File deleted: %s\n", prevFile->name);

            // Silinen dosyayı listeden kaldır
            for (int k = i; k < *prevCount - 1; ++k) {
                (*prevFiles)[k] = (*prevFiles)[k + 1];
            }
            *prevCount -= 1;
            *prevFiles = (FileInfo*)realloc(*prevFiles, (*prevCount) * sizeof(FileInfo));

            // İndeks geri alındı, bir sonraki dosya kontrol edilsin
            i -= 1;
        }
    }

    // Bellek temizleme
    for (int i = 0; i < curCount; ++i) {
        free(curEntries[i]);
    }
    free(curEntries);
}

void monitorDirectory(const char* folderPath) {
    FileInfo* prevFiles = NULL;
    int prevCount = 0;

    while (1) {
        checkDirectory(folderPath, &prevFiles, &prevCount);
        sleep(1);
    }

    free(prevFiles);
}

int main(int argc, char const *argv[])
{
    /* code */

    char dirname[256] = {0};
    snprintf(dirname,sizeof(dirname),"%s",argv[1]);
    printf("dirname : %s\n",dirname);
    monitorDirectory(dirname);

    //const char* folderPath = "/home/tangel/Lessons/System-Prog/2023/Final/inotify"; // İzlemek istediğiniz dizinin yolu


    return 0;
}
