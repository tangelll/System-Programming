#ifndef FUNCTIONS /* Include guard */
#define FUNCTIONS

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <fcntl.h>
#include <string.h>
#include <dirent.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/time.h>

#define FILENAME_SIZE 256
#define PATH_MAX_LENGTH 4096
#define BUFFER_SIZE 10




typedef struct {
    int fileDescSrc;
    int fileDescDest;
    char filename[FILENAME_SIZE];
    char srcDir [FILENAME_SIZE];
    char destDir[FILENAME_SIZE]; 

} BufferItem;


typedef struct {
    BufferItem *buffer;
    int bufferSize;
    int in; // index to add items to buffer.
    int out; // index to remove items from bugger
    int count; // number of items in the buffer we count it.
    int done; // done flag in hhmw5
    pthread_mutex_t mutex; // mutex 
    pthread_cond_t full; // condition variable for  full buffer
    pthread_cond_t empty; // condition variable for  empty buffer
} SharedBuffer;

SharedBuffer *sharedBuffer;
int total_number_of_bytes = 0;
int first_time = 0;
volatile sig_atomic_t flag = 0;

void copyingFile(const char* srcPath, const char* destPath) {
    // Open the source file for reading
    int srcFileDesc = open(srcPath, O_RDONLY);
    if (srcFileDesc == -1) {
        perror("Failed to open source file");
        return;
    }

    // Open the destination file for writing
    int destFileDesc = open(destPath, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (destFileDesc == -1) {
        perror("Failed to create destination file");
        close(srcFileDesc);
        return;
    }

    // Copy the contents from the source file to the destination file
    char buffer[1024];
    ssize_t bytesRead, bytesWritten;
    while ((bytesRead = read(srcFileDesc, buffer, sizeof(buffer))) > 0) {
        bytesWritten = write(destFileDesc, buffer, bytesRead);
        if (bytesWritten != bytesRead) {
            perror("Failed to write to destination file");
            break;
        }
    }

    total_number_of_bytes = total_number_of_bytes + bytesWritten;
    printf("written bytes %d\n",total_number_of_bytes);


    // Close the file descriptors
    close(srcFileDesc);
    close(destFileDesc);

    printf("File copied: %s\n", srcPath);
}


void copyingDirectory( char* srcDir ,  char* destDir) {
    
    char srcPath[FILENAME_SIZE];
    char destPath[FILENAME_SIZE];    
    

    
    // Open the source directory
    DIR* dir = opendir(srcDir);
    printf("sordir %s \n",srcDir);
    if (dir == NULL) {
        perror("Failed to open source directory");
        return;
    }

    DIR *dir2 = opendir(destDir);

    if ( first_time == 0){
        if( dir2 == NULL)  {
                first_time =1;

            // Create the destination directory
            if (mkdir(destDir, 0755) == -1) {
                perror("Failed to create destination directory");
                closedir(dir);
                return;
            }
        }
    }
    else{
        // Create the destination directory
        if (mkdir(destDir, 0755) == -1) {
            perror("Failed to create destination directoryyyy");
            closedir(dir);
            return;
        }
    }
   


    struct dirent* entry;
    while ((entry = readdir(dir)) != NULL) {
        if(flag){
            return;
        }
        // Skip "." and ".." entries
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
            continue;
        }

        int ret =  snprintf(srcPath, PATH_MAX_LENGTH, "%s/%s", srcDir, entry->d_name);
        
        if (ret < 0) {
            abort();
            }

        ret = snprintf(destPath, PATH_MAX_LENGTH, "%s/%s", destDir, entry->d_name);
        if (ret < 0) {
            abort();
        }

       
        // Check if the entry is a directory
        struct stat entryStat;
        if (lstat(srcPath, &entryStat) == -1) {
            perror("Failed to get file status");
            continue;
        }

        if (S_ISDIR(entryStat.st_mode)) {
            // Entry is a directory
            copyingDirectory(srcPath, destPath);
        } else if (S_ISREG(entryStat.st_mode)) {
            // Entry is a regular file
            copyingFile(srcPath, destPath);
        } else if (S_ISFIFO(entryStat.st_mode)) {
            // Entry is a named pipe (FIFO)

            #if 0
            // Create the named pipe in the destination directory
            if (mkfifo(destPath, entryStat.st_mode & ~S_IFIFO) == -1) {
                perror("Failed to create destination named pipe");
                continue;
            }
            #endif

            printf("Named pipe copied: %s\n", srcPath);
        } else {
            // Entry is a special file, socket, etc.
            printf("Skipping special file: %s\n", srcPath);
        } 
    }

    closedir(dir);
    closedir(dir2);

}



void initializeSharedBuffer(int bufferSize) {
    
    int shmid = shmget(IPC_PRIVATE, sizeof(SharedBuffer) + bufferSize * sizeof(BufferItem), IPC_CREAT | 0666);
    if (shmid < 0) {
        perror("Failed to create shared memory segment");
        exit(1);
    }

    sharedBuffer = (SharedBuffer *)shmat(shmid, NULL, 0);
    if (sharedBuffer == (SharedBuffer *)-1) {
        perror("Failed to attach shared memory segment");
        exit(1);
    }

    sharedBuffer->buffer = (BufferItem *)(sharedBuffer + 1); // Set the buffer pointer after the SharedBuffer struct

    sharedBuffer->bufferSize = bufferSize;
    sharedBuffer->in = 0;
    sharedBuffer->out = 0;
    sharedBuffer->count = 0;
    sharedBuffer->done = 0;
    pthread_mutex_init(&(sharedBuffer->mutex), NULL);
    pthread_cond_init(&(sharedBuffer->full), NULL);
    pthread_cond_init(&(sharedBuffer->empty), NULL);
}

void destroySharedBuffer() {
    pthread_mutex_destroy(&sharedBuffer->mutex);
    pthread_cond_destroy(&sharedBuffer->full);
    pthread_cond_destroy(&sharedBuffer->empty);

    shmdt(sharedBuffer);
}
#endif // FOO_H_
