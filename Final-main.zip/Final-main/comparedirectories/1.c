
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>

int countDirectoryContent(const char* dirPath) {
    int count = 0;
    DIR* dir = opendir(dirPath);
    if (dir == NULL) {
        perror("Failed to open directory");
        exit(EXIT_FAILURE);
    }

    struct dirent* entry;
    while ((entry = readdir(dir)) != NULL) {
        if (strcmp(entry->d_name, ".") != 0 && strcmp(entry->d_name, "..") != 0) {
            count++;
        }
    }

    closedir(dir);
    return count;
}

int compareDirectories(const char* dirPath1, const char* dirPath2) {
    int count1 = countDirectoryContent(dirPath1);
    int count2 = countDirectoryContent(dirPath2);

    if (count1 > count2) {
        return 1;
    } else if (count1 < count2) {
        return -1;
    } else{
        return 0;
    }
}

int main() {
     const char* dir1 = "/home/tangel/Lessons/System-Prog/2023/Final/clientdir";
    const char* dir2 = "/home/tangel/Lessons/System-Prog/2023/Final";

    int result = compareDirectories(dir1, dir2);
    printf("Directory with more content: %d\n", result);


    return 0;
}
