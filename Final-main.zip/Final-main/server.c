#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include <pthread.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/ipc.h>
#include <fcntl.h>
#include <string.h>
#include <dirent.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/inotify.h>

#define MAX_CLIENTS 100
#define BUFFER_SIZE 1024




/*


typedef struct {
    int client_socket;
    char* client_dir;
    char* server_dir;
    char filename [1024];
} ClientInfo;


*/

typedef struct {
    char name[256];
    time_t lastModified;
    off_t size;
} FileInfo;



    // Define the structure for a client connection
typedef struct Client {
    int clientSocket;
    char* client_dir;
    char* server_dir;
    char filename [1024];
    struct Client* next;
} Client;


// Define the structure for the queue
typedef struct Queue {
    Client* front;
    Client* rear;
} Queue;




// Initialize an empty queue
void initializeQueue(Queue* queue) {
    queue->front = NULL;
    queue->rear = NULL;
}

// Check if the queue is empty
int isQueueEmpty(Queue* queue) {
    return queue->front == NULL;
}

// Add a client connection to the queue (push operation)
void enqueue(Queue* queue, int clientSocket) {
    Client* newClient = (Client*)malloc(sizeof(Client));
    newClient->clientSocket = clientSocket;
    newClient->next = NULL;

    if (isQueueEmpty(queue)) {
        queue->front = newClient;
        queue->rear = newClient;
    } else {
        queue->rear->next = newClient;
        queue->rear = newClient;
    }
}

// Remove and return the front client connection from the queue (pop operation)
int dequeue(Queue* queue) {
    if (isQueueEmpty(queue)) {
        printf("Error: Queue is empty.\n");
        exit(EXIT_FAILURE);
    }

    Client* temp = queue->front;
    int clientSocket = temp->clientSocket;

    queue->front = queue->front->next;
    free(temp);

    // If the queue becomes empty after dequeue
    if (queue->front == NULL) {
        queue->rear = NULL;
    }

    return clientSocket;
}


// Initialize thread pool
pthread_t thread_pool[MAX_CLIENTS];
// Accept incoming client connections
struct sockaddr_in client_address;
socklen_t client_address_length = sizeof(client_address);
struct stat st;
int server_socket;
int thread_pool_size;
//int file;

char  FilenamesShouldSend[512][512] = {0};
int filesth = 0;

FileInfo* prevFiles = NULL;
int prevCount = 0;

Queue clientQueue;

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;




void checkDirectory(const char* folderPath, FileInfo** prevFiles, int* prevCount) {
    struct dirent** curEntries;
    int curCount;

    curCount = scandir(folderPath, &curEntries, NULL, alphasort);
    if (curCount == -1) {
        perror("Failed to scan directory");
        exit(EXIT_FAILURE);
    }

    // Yeni eklenen dosyaları kontrol et
    for (int i = 0; i < curCount; ++i) {
        struct dirent* curEntry = curEntries[i];

        if (curEntry->d_type == DT_REG) { // Sadece dosyalara odaklanır
            int isNew = 1;
            for (int j = 0; j < *prevCount; ++j) {
                FileInfo* prevFile = &((*prevFiles)[j]);

                if (strcmp(curEntry->d_name, prevFile->name) == 0) {
                    isNew = 0;

                    struct stat curStat;
                    char curFilePath[512];
                    sprintf(curFilePath, "%s/%s", folderPath, curEntry->d_name);

                    if (stat(curFilePath, &curStat) == 0) {
                        // Dosyanın son değiştirilme zamanı veya boyutu değişti mi?
                        if (curStat.st_mtime != prevFile->lastModified || curStat.st_size != prevFile->size) {
                            printf("File modified: %s\n", curEntry->d_name);
                            strcpy(FilenamesShouldSend[filesth],curEntry->d_name);
                            filesth++;
                            // Son değiştirilme zamanını ve boyutunu güncelle
                            prevFile->lastModified = curStat.st_mtime;
                            prevFile->size = curStat.st_size;
                        }
                    }
                    break;
                }
            }

            if (isNew) {
                printf("New file added: %s\n", curEntry->d_name);
                strcpy(FilenamesShouldSend[filesth],curEntry->d_name);
                filesth++;

                // Yeni dosya için FileInfo oluştur ve kaydet
                FileInfo newFile;
                strcpy(newFile.name, curEntry->d_name);
                struct stat curStat;
                char curFilePath[512];
                sprintf(curFilePath, "%s/%s", folderPath, curEntry->d_name);

                if (stat(curFilePath, &curStat) == 0) {
                    newFile.lastModified = curStat.st_mtime;
                    newFile.size = curStat.st_size;
                }
                *prevCount += 1;
                *prevFiles = (FileInfo*)realloc(*prevFiles, (*prevCount) * sizeof(FileInfo));
                (*prevFiles)[*prevCount - 1] = newFile;
            }
        }
    }

    // Silinen dosyaları kontrol et
    for (int i = 0; i < *prevCount; ++i) {
        FileInfo* prevFile = &((*prevFiles)[i]);
        int isDeleted = 1;

        for (int j = 0; j < curCount; ++j) {
            struct dirent* curEntry = curEntries[j];

            if (strcmp(curEntry->d_name, prevFile->name) == 0) {
                isDeleted = 0;
                break;
            }
        }

        if (isDeleted) {
            printf("File deleted: %s\n", prevFile->name);

            // Silinen dosyayı listeden kaldır
            for (int k = i; k < *prevCount - 1; ++k) {
                (*prevFiles)[k] = (*prevFiles)[k + 1];
            }
            *prevCount -= 1;
            *prevFiles = (FileInfo*)realloc(*prevFiles, (*prevCount) * sizeof(FileInfo));

            // İndeks geri alındı, bir sonraki dosya kontrol edilsin
            i -= 1;
        }
    }

    // Bellek temizleme
    for (int i = 0; i < curCount; ++i) {
        free(curEntries[i]);
    }
    free(curEntries);
}

void monitorDirectory(const char* folderPath) {
   

        checkDirectory(folderPath, &prevFiles, &prevCount);
        //sleep(1);
    

}

volatile sig_atomic_t flag = 0;

void handleSignal(int signal )
{

printf("Received SIGINT signal\n");
printf("Closing Threads and files\n");

 sleep(1);
    



     flag = 1;  // Sigint sinyali alındığında bayrağı işaretle

}


void sendFile(int clientSocket, const char *filePath) {

    int file;


    // Open the file for reading
    file = open(filePath, O_RDONLY);
    if (file == -1) {
        printf("filepath: %s\n",filePath);
        perror("Failed to open file");
        exit(EXIT_FAILURE);
    }



    // Acquire file lock
    struct flock fl;
    fl.l_type = F_RDLCK;  // Read lock
    fl.l_whence = SEEK_SET;
    fl.l_start = 0;
    fl.l_len = 0;  // Lock entire file

    if (fcntl(file, F_SETLK, &fl) == -1) {
        perror("Failed to acquire file lock");
        exit(EXIT_FAILURE);
    }

    //deneme
    // Read the file contents and send them to the client
    char buffer[BUFFER_SIZE] ={0};
    ssize_t bytesRead;
    while ((bytesRead = read(file, buffer, BUFFER_SIZE)) > 0) {
        if (send(clientSocket, buffer, 1024, 0) == -1) {
            perror("Failed to send data");
            exit(EXIT_FAILURE);
        }
        //printf("buffer %s\n",buffer);
        memset(buffer,0,sizeof(buffer));

    }

    printf("close file \n ");
    const char *sentflag ="*FILESENT*";
    send(clientSocket,sentflag, 1024, 0);


     // Release file lock
    fl.l_type = F_UNLCK;
    if (fcntl(file, F_SETLK, &fl) == -1) {
        perror("Failed to release file lock");
        exit(EXIT_FAILURE);
    }

    // Close the file
    close(file);
}

void sendDirectory(int clientSocket, const char *dirPath) {
    // Open the directory
    DIR *dir = opendir(dirPath);
    if (dir == NULL) {
        perror("Failed to open directory");
        exit(EXIT_FAILURE);
    }


 
    // Read the directory entries
    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL  ) {
        // Skip "." and ".." entries
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
            continue;
        }

        // Construct the full path of the entry
        char entryPath[PATH_MAX];
         int ret = snprintf(entryPath, PATH_MAX, "%s/%s", dirPath, entry->d_name);

        if (ret < 0) {
        abort();
        }

        //printf("%s\n",entryPath);


        struct stat entryStat;

        if (lstat(entryPath, &entryStat) == -1) {
            perror("Failed to get file status");
            continue;
        }

        if (S_ISDIR(entryStat.st_mode)) {

            #if 0
            // Entry is a directory
            char filename[512]= {0};
            snprintf(filename,sizeof(filename),"DIRECTORY:%s",entry->d_name);
            send(clientSocket,filename , sizeof(filename), 0);
            sendDirectory(clientSocket, entryPath);
            
            #endif

        } else if (S_ISREG(entryStat.st_mode) ) {
            // Entry is a regular file
            char filename[512]= {0};
            snprintf(filename,sizeof(filename),"FILENAME:%s",entry->d_name);
            send(clientSocket,filename , sizeof(filename), 0);
            //send(clientSocket, entry->d_name, strlen(entry->d_name), 0);
            //sleep(1);
            //send(clientSocket, "FILE", sizeof("FILE"), 0);
            sendFile(clientSocket,entry->d_name);
            printf("filepath: %s\n",entry->d_name);
        } else if (S_ISFIFO(entryStat.st_mode)) {
            // Entry is a named pipe (FIFO)

            #if 0
            // Create the named pipe in the destination directory
            if (mkfifo(destPath, entryStat.st_mode & ~S_IFIFO) == -1) {
                perror("Failed to create destination named pipe");
                continue;
            }
            #endif

            printf("Named pipe copied: \n");
        } else {
            // Entry is a special file, socket, etc.
                printf("Skipping special file: \n");
  
        } 

    }
    
    char buffer[1024]={0};
    send(clientSocket, buffer, 1024, 0);
    printf("END OF SEND DIRECTORY\n");

    // Close the directory
    closedir(dir);
}

void receiveFile(int socket, const char* filename) {
    
 
    // Open the destination file for writing
    int destFileDesc = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (destFileDesc == -1) {
        perror("Failed to create destination file");
        close(destFileDesc);
        return;
    }

           // Acquire file lock
    struct flock fl;
    fl.l_type = F_WRLCK;  // Write lock
    fl.l_whence = SEEK_SET;
    fl.l_start = 0;
    fl.l_len = 0;  // Lock entire file

    if (fcntl(destFileDesc, F_SETLK, &fl) == -1) {
        perror("Failed to acquire file lock");
        exit(EXIT_FAILURE);
    }



   // Copy the contents from the source file to the destination file
    char buffer[1024] = {0};
    ssize_t bytesRead, bytesWritten;
    while ((bytesRead = recv(socket, buffer, sizeof(buffer), 0)) >= 0) {

        //printf("buffer: %s\n",buffer);
        if(strncmp(buffer, "*FILESENT*",strlen("*FILESENT*")) == 0){
            char eof[12] = {0};
            bytesWritten = write(destFileDesc, eof, 12);
            printf("FILE RECIEVED SUCCESFUL\n");
            break;
        }
        bytesWritten = write(destFileDesc, buffer, bytesRead);
        if (bytesWritten != bytesRead) {
            perror("Failed to write to destination file");
            break;
        }
        
        memset(buffer,0,sizeof(buffer));
    }

        //    Release file lock
        fl.l_type = F_UNLCK;
        if (fcntl(destFileDesc, F_SETLK, &fl) == -1) {
            perror("Failed to release file lock");
            exit(EXIT_FAILURE);
        }


    printf("BUFFER %s\n",buffer);
    close(destFileDesc);
    printf("Received file: %s\n", filename);
}


void receiveDirectory(int socket, const char* currentPath) {
    char Firstfilename[512]= {0};
    ssize_t bytesRead;

    printf("SERVER START TO TAKE FILES\n");
    while ((bytesRead = recv(socket, Firstfilename, sizeof(Firstfilename), 0)) > 0  ) {
        
    

      
        if (strncmp(Firstfilename, "DIRECTORY",strlen("DIRECTORY")) == 0) {
            #if 0
            // Receive a subdirectory name
            memset(buffer, 0, sizeof(buffer));
            recv(socket, buffer, sizeof(buffer), 0);
            char subdirectoryPath[BUFFER_SIZE];
            snprintf(subdirectoryPath, strlen(subdirectoryPath) +1 , "%s/%s", currentPath, buffer);

            // Create the subdirectory
            mkdir(subdirectoryPath, 0755);

            // Enter the subdirectory
            chdir(subdirectoryPath);

            // Receive the subdirectory's contents
            receiveDirectory(socket, subdirectoryPath);

            // Move back to the parent directory
            chdir("..");
            #endif
        } else if (strncmp(Firstfilename, "FILENAME",strlen("FILENAME")) == 0) {


           

            //normadle
            char filepath[1024] = {0};
            char filename[512] = {0};
            // Receive a file name
            
            snprintf(filename,sizeof(filename),"%s",&Firstfilename[9]);



            snprintf(filepath, sizeof(filepath), "%s/%s", currentPath, filename);
            printf("filepath: %s\n",filepath);

            // Receive the file
            receiveFile(socket, filepath);

        }
        else{
            printf("Unkkonw type\n");
            break;
           
        }
    }
        printf("END OF RECIEVE  DIRECTORY\n");

    
}


void synchronizeDirectories(const char* server_dir, const char* client_dir) {
    // TODO: Implement directory synchronization logic
    // Compare files in the server_dir and client_dir
    // Perform necessary actions to synchronize them
    // For example, copy missing files from server_dir to client_dir
}

void updateLogFile(const char* client_dir, const char* filename, const char* action) {
    // TODO: Implement log file update logic
    // Open the log file in the client_dir
    // Append the filename and action (created, deleted, or updated)
    // Include the access time if needed
}

void* handleClient(void* arg) {
    
    Client* client_info = (Client*)arg;
    int client_socket = client_info->clientSocket;
    char server_dir[1024];
    strcpy(server_dir,client_info->server_dir);

    
    char buffer[BUFFER_SIZE] = {0};
    ssize_t send_bytes;
    pthread_mutex_lock(&mutex);  // Acquire the mutex lock
    printf("Client connected. Address: %d\n", client_socket);

    //char buffer[BUFFER_SIZE] = {0};

    // Prompt message on the server side

    // Receive and process client messages
    //ssize_t recv_bytes =0;


    //sendDirectory(client_socket, server_dir);
    

    filesth =0;       
    char number[12] = {0};
   // monitorDirectory(server_dir);
   // sprintf(number, "%d", filesth);
    //printf("num: %s\n",number);
    //int value = send(client_socket,number, sizeof(number), 0);     

    //printf("value: %d",value);    
   // if( filesth > 1){

    sendDirectory(client_socket, server_dir);

 
   // }




   // receiveDirectory(client_socket, server_dir);

    
    pthread_mutex_unlock(&mutex);  // Release the mutex lock

    free(client_info);
    pthread_exit(NULL);
}

void signalHandler(int signum) {
    // TODO: Handle SIGINT signal
    // Perform any necessary cleanup before exiting
    exit(0);
}

int main(int argc, char* argv[]) {

    struct sigaction act;
    act.sa_handler = handleSignal;
    sigemptyset(&act.sa_mask);
    act.sa_flags = 0;
    sigaction(SIGINT, &act, NULL);




    if (argc != 4) {
        printf("Usage: %s [directory] [threadPoolSize] [portnumber]\n", argv[0]);
        return 1;
    }

    const char* server_dir = argv[1];
    thread_pool_size = atoi(argv[2]);
    int port_number = atoi(argv[3]);



    char cwd[256];
    if (stat(server_dir, &st) == -1)
    {
        // directory does not exist, so create it
        if (mkdir(server_dir, 0700) == -1)
        {
            perror("mkdir");
            return 1;
        }
    }

    if (chdir(server_dir) == -1)
    {
        perror("chdir");
        return 1;
    }
    else
    {
        if (getcwd(cwd, sizeof(cwd)) == NULL)
            perror("getcwd() error");
    }



    // Create server socket
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket == -1) {
        perror("socket");
        return 1;
    }

    // Set up server address
    struct sockaddr_in server_address;
    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = htonl(INADDR_ANY);
    server_address.sin_port = htons(port_number);

    // Bind server socket to the address
    if (bind(server_socket, (struct sockaddr*)&server_address, sizeof(server_address)) == -1) {
        perror("bind");
        return 1;
    }

    // Listen for client connections
    if (listen(server_socket, MAX_CLIENTS) == -1) {
        perror("listen");
        return 1;
    }

    initializeQueue(&clientQueue);

    int client_socket=0;
    int connected_clients = 0;
    while (!flag ) {

        //hop
    // Accept client connection


    client_socket = accept(server_socket, (struct sockaddr*)&client_address, &client_address_length);
    if (client_socket == -1) {
        perror("accept");
        exit(0);
        //continue;
    }
      
    if (connected_clients >= thread_pool_size) {
        // Maximum number of clients reached
        printf("Warning: Maximum number of clients reached. Connection request ignored.\n");
        close(client_socket);
        continue;
    }

    enqueue(&clientQueue, client_socket);
    connected_clients++;

    /* DEGISIKLIK CLIENTTE YAPILDIYSA ONCE SERVARA GIT ORDA YAP SONRA BUTUN CLIENTLERE YAP
       DEGISIKLIK SERVERDA YAPILDIYSA DIREK CLIENTLERE GIT ONLARA YAP.
       DOSYA ISMI ALARAK DOSYA SILME ,EKLEME,UPDATE ETMEN LAZIM.
       BIRDE SUBDIRECTORY YAPMIYOSUN ONU EKLEMEN LAZIM.
     */
    char buffer[BUFFER_SIZE] = {0};
    ssize_t send_bytes;

        // TODO: Process server messages if needed
        // You can add specific message formats and actions here
   



        // TODO: Process server messages if needed
        // You can add specific message formats and actions here
    // Create Client struct to pass to the thread
    Client* client_info = (Client*)malloc(sizeof(Client));
    client_info->clientSocket = client_socket;    
    client_info->server_dir = strdup(cwd);  // Assign client directory here
    // Create a new thread to handle the client


    pthread_create(&thread_pool[client_socket % thread_pool_size], NULL, handleClient, (void*)client_info);
    
    printf("%d\n", dequeue(&clientQueue));

    }
        
    // Join the threads
    for (int i = 0; i < MAX_CLIENTS; i++) {
        pthread_join(thread_pool[i], NULL);
    }


free(prevFiles);

// Close server socket
close(server_socket);

return 0;
}

