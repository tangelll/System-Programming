#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include <pthread.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/ipc.h>
#include <fcntl.h>
#include <string.h>
#include <dirent.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <limits.h>
#include <arpa/inet.h>
#include <sys/inotify.h>
#include <time.h>


#define MESSAGE_SIZE 1024
#define BUFFER_SIZE 1024

typedef struct {
    int client_socket;
    char* client_dir;
    char* server_dir;
    char filename [1024];
} ClientInfo;

typedef struct {
    char name[256];
    time_t lastModified;
    off_t size;
} FileInfo;


char  FilenamesShouldSend[512][512] = {0};
int filesth = 0;
FileInfo* prevFiles = NULL;
int prevCount = 0;
int client_socket=0;
FILE* log_file;

volatile sig_atomic_t flag = 0;

void handleSignal(int signal )
{

fprintf(stderr, "Received SIGINT signal\n");
fprintf(stderr, "Closing  files.\n");

 sleep(1);
    
   
    flag = 1;  // Sigint sinyali alındığında bayrağı işaretle

    
}


void checkDirectory(const char* folderPath, FileInfo** prevFiles, int* prevCount) {
   struct dirent** curEntries;
    int curCount;

    curCount = scandir(folderPath, &curEntries, NULL, alphasort);
    if (curCount == -1) {
        perror("Failed to scan directory");
        exit(EXIT_FAILURE);
    }

    // Yeni eklenen dosyaları kontrol et
    for (int i = 0; i < curCount; ++i) {
        struct dirent* curEntry = curEntries[i];

        if (curEntry->d_type == DT_REG) { // Sadece dosyalara odaklanır
            int isNew = 1;
            for (int j = 0; j < *prevCount; ++j) {
                FileInfo* prevFile = &((*prevFiles)[j]);

                if (strcmp(curEntry->d_name, prevFile->name) == 0) {
                    isNew = 0;

                    struct stat curStat;
                    char curFilePath[512];
                    sprintf(curFilePath, "%s/%s", folderPath, curEntry->d_name);

                    if (stat(curFilePath, &curStat) == 0) {
                        // Dosyanın son değiştirilme zamanı veya boyutu değişti mi?
                        if (curStat.st_mtime != prevFile->lastModified || curStat.st_size != prevFile->size) {
                            printf("File modified: %s\n", curEntry->d_name);
                            strcpy(FilenamesShouldSend[filesth],curEntry->d_name);
                            filesth++;
                            // Son değiştirilme zamanını ve boyutunu güncelle
                            prevFile->lastModified = curStat.st_mtime;
                            prevFile->size = curStat.st_size;
                        }
                    }
                    break;
                }
            }

            if (isNew) {
                printf("New file added: %s\n", curEntry->d_name);
                strcpy(FilenamesShouldSend[filesth],curEntry->d_name);
                filesth++;

                // Yeni dosya için FileInfo oluştur ve kaydet
                FileInfo newFile;
                strcpy(newFile.name, curEntry->d_name);
                struct stat curStat;
                char curFilePath[512];
                sprintf(curFilePath, "%s/%s", folderPath, curEntry->d_name);

                if (stat(curFilePath, &curStat) == 0) {
                    newFile.lastModified = curStat.st_mtime;
                    newFile.size = curStat.st_size;
                }
                *prevCount += 1;
                *prevFiles = (FileInfo*)realloc(*prevFiles, (*prevCount) * sizeof(FileInfo));
                (*prevFiles)[*prevCount - 1] = newFile;
            }
        }
    }

    // Silinen dosyaları kontrol et
    for (int i = 0; i < *prevCount; ++i) {
        FileInfo* prevFile = &((*prevFiles)[i]);
        int isDeleted = 1;

        for (int j = 0; j < curCount; ++j) {
            struct dirent* curEntry = curEntries[j];

            if (strcmp(curEntry->d_name, prevFile->name) == 0) {
                isDeleted = 0;
                break;
            }
        }

        if (isDeleted) {
            printf("File deleted: %s\n", prevFile->name);

            // Silinen dosyayı listeden kaldır
            for (int k = i; k < *prevCount - 1; ++k) {
                (*prevFiles)[k] = (*prevFiles)[k + 1];
            }
            *prevCount -= 1;
            *prevFiles = (FileInfo*)realloc(*prevFiles, (*prevCount) * sizeof(FileInfo));

            // İndeks geri alındı, bir sonraki dosya kontrol edilsin
            i -= 1;
        }
    }

    // Bellek temizleme
    for (int i = 0; i < curCount; ++i) {
        free(curEntries[i]);
    }
    free(curEntries);
}

void monitorDirectory(const char* folderPath) {

    checkDirectory(folderPath, &prevFiles, &prevCount);
    // sleep(1);
    

}


void sendFile(int clientSocket, const char *filePath) {


    // Open the file for reading
    int file = open(filePath, O_RDONLY);
    if (file == -1) {
        perror("Failed to open file");
        exit(EXIT_FAILURE);
    }

    // Read the file contents and send them to the client
    char buffer[BUFFER_SIZE] ={0};
    ssize_t bytesRead;
    while ((bytesRead = read(file, buffer, BUFFER_SIZE)) > 0) {
        if (send(clientSocket, buffer, 1024, 0) == -1) {
            perror("Failed to send data");
            exit(EXIT_FAILURE);
        }
        //printf("buffer %s\n",buffer);
        memset(buffer,0,sizeof(buffer));

    }

    const char *sentflag ="*FILESENT*";
    
    send(clientSocket,sentflag, 1024, 0);
    // Close the file
    close(file);
}

void sendDirectory(int clientSocket, const char *dirPath) {
    // Open the directory


    time_t current_time = time(NULL);

    // Convert the time to a local time string
    char time_string[100];
    strftime(time_string, sizeof(time_string), "%Y-%m-%d %H:%M:%S", localtime(&current_time));

   
    printf("CLIENT START TO SEND FILES \n");
    //printf("Current time: %s\n", time_string);

    DIR *dir = opendir(dirPath);
    if (dir == NULL) {
        perror("Failed to open directory");
        exit(EXIT_FAILURE);
    }


 
    // Read the directory entries
    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        // Skip "." and ".." entries
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
            continue;
        }

        // Construct the full path of the entry
        char entryPath[PATH_MAX];
         int ret = snprintf(entryPath, PATH_MAX, "%s/%s", dirPath, entry->d_name);

        if (ret < 0) {
        abort();
        }

        //printf("%s\n",entryPath);


        struct stat entryStat;

        if (lstat(entryPath, &entryStat) == -1) {
            perror("Failed to get file status");
            continue;
        }

        if (S_ISDIR(entryStat.st_mode)) {

            #if 0
            // Entry is a directory
            int j =send(clientSocket, "DIRECTORY", sizeof("DIRECTORY"), 0);
            int k = send(clientSocket, entry->d_name, strlen(entry->d_name), 0);
            //printf("j k %d %d\n",j,k);
            sendDirectory(clientSocket, entryPath);
            #endif
        } else if (S_ISREG(entryStat.st_mode)) {
            printf("FILE IS SENDING\n");
            printf("Current time: %s\n", time_string);

            // Entry is a regular file
            char filename[512]= {0};
            snprintf(filename,sizeof(filename),"FILENAME:%s",entry->d_name);
            printf("fn:%s\n",entry->d_name);
            send(clientSocket,filename , sizeof(filename), 0);
            //send(clientSocket, entry->d_name, strlen(entry->d_name), 0);
            //send(clientSocket, "FILE", sizeof("FILE"), 0);
            sendFile(clientSocket,entry->d_name);
        } else if (S_ISFIFO(entryStat.st_mode)) {
            // Entry is a named pipe (FIFO)

            #if 0
            // Create the named pipe in the destination directory
            if (mkfifo(destPath, entryStat.st_mode & ~S_IFIFO) == -1) {
                perror("Failed to create destination named pipe");
                continue;
            }
            #endif

            printf("Named pipe copied: \n");
           printf("Current time: %s\n", time_string);
           
        } else {
            // Entry is a special file, socket, etc.
            printf("Skipping special file: \n");
            printf("Current time: %s\n", time_string);

        } 



    }

    char buffer[1024]={0};
    send(clientSocket, buffer, 1024, 0);
    printf("END OF SEND DIRECTORY\n");
   // printf("Current time: %s\n", time_string);


    // Close the directory
    closedir(dir);
}




void receiveFile(int socket, const char* filename) {
    

    // Open the destination file for writing
    int destFileDesc = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (destFileDesc == -1) {
        perror("Failed to create destination file");
        close(destFileDesc);
        return;
    }

    

    // Copy the contents from the source file to the destination file
    char buffer[1024] = {0};
    ssize_t bytesRead, bytesWritten;
    while ((bytesRead = recv(socket, buffer, sizeof(buffer), 0)) > 0) {

        //printf("buffer: %s\n",buffer);
        if(strncmp(buffer, "*FILESENT*",strlen("*FILESENT*")) == 0){
            char eof[12] = {0};
            bytesWritten = write(destFileDesc, eof, 12);
            printf("FILE RECIEVED SUCCESFUL\n");
            break;
        }
        bytesWritten = write(destFileDesc, buffer, bytesRead);
        if (bytesWritten != bytesRead) {
            perror("Failed to write to destination file");
            break;
        }
        
        memset(buffer,0,sizeof(buffer));
    }


    close(destFileDesc);
    //printf("Received file: %s\n", filename);
}




void receiveDirectory(int socket, const char* currentPath) {
    char Firstfilename[512]= {0};
    ssize_t bytesRead;
    while ((bytesRead = recv(socket, Firstfilename, sizeof(Firstfilename), 0)) > 0) {

        if (strncmp(Firstfilename, "DIRECTORY",strlen("DIRECTORY")) == 0) {
            printf("Directory type\n");

            #if 0
            // Receive a subdirectory name
            char subdirectoryPath[1024] = {0};
            char filename[512] = {0};

            //recieve directoryname
            snprintf(filename,sizeof(filename),"%s",&Firstfilename[10]);


            //make directory name
            snprintf(subdirectoryPath, sizeof(subdirectoryPath), "%s/%s", currentPath, filename);
            printf("subdirectoryPath %s\n",subdirectoryPath);

            // Create the subdirectory
            mkdir(subdirectoryPath, 0755);

            // Enter the subdirectory
            chdir(subdirectoryPath);

            // Receive the subdirectory's contents
            receiveDirectory(socket, subdirectoryPath);

            // Move back to the parent directory
            chdir("..");
            #endif
        } else if (strncmp(Firstfilename, "FILENAME",strlen("FILENAME")) == 0) {

            printf("Filename type\n");

            //normadle
            char filepath[1024] = {0};
            char filename[512] = {0};
            
            // Receive a file name
            snprintf(filename,sizeof(filename),"%s",&Firstfilename[9]);


            //make filepath
            snprintf(filepath, sizeof(filepath), "%s/%s", currentPath, filename);
            printf("filepath: %s\n",filepath);

            // Receive the file
            receiveFile(socket, filepath);


        }
        else{
            printf("Unkkonw type\n");
            break;
           
        }
    }
    printf("END OF RECIEVE  DIRECTORY\n");

    
}





void signalHandler(int signum) {
    // TODO: Handle SIGINT signal
    // Perform any necessary cleanup before exiting
    exit(0);
}

    
int main(int argc, char* argv[]) {

    time_t current_time = time(NULL);

    // Convert the time to a local time string
    char time_string[100];
    strftime(time_string, sizeof(time_string), "%Y-%m-%d %H:%M:%S", localtime(&current_time));

    // Print the timestamp
    printf("Current time: %s\n", time_string);
     struct sigaction act;
    act.sa_handler = handleSignal;
    sigemptyset(&act.sa_mask);
    act.sa_flags = 0;
    sigaction(SIGINT, &act, NULL);


    pid_t process_id = getpid();

    // Generate the log file name
    char log_file_name[100]="logfile.log";

   
  
    char dir_name[512];
    int port_number;
    char server_ip[512];

    if(argc == 3){

        strcpy(dir_name,argv[1]);
        port_number = atoi(argv[2]);
        strcpy(server_ip,"127.0.0.1");

    }
    if(argc ==4){

        strcpy(dir_name,argv[1]);
        port_number = atoi(argv[2]);
        strcpy(server_ip,argv[3]);
        
    }
    if ( argc < 3 ) {
        printf("Usage: %s [dirName] [portnumber] [ip] \n", argv[0]);
        return 1;
    }

    printf("%s\n",dir_name);
    printf("%d\n",port_number);
    printf("%s\n",server_ip);





    char cwd[PATH_MAX]= {0};  // PATH_MAX is a constant defined in <limits.h>
    struct stat st;
    if (stat(dir_name, &st) == -1)
    {
        // directory does not exist, so create it
        if (mkdir(dir_name, 0700) == -1)
        {
            perror("mkdir");
            return 1;
        }
    }

    if (chdir(dir_name) == -1)
    {
        perror("chdir");
        return 1;
    }
    else
    {
        if (getcwd(cwd, sizeof(cwd)) == NULL)
            perror("getcwd() error");
    }

    printf("Writing operation to logfile\n");

     // Open the log file in write mode
    log_file = fopen(log_file_name, "a");

    if (log_file == NULL) {
        printf("Error opening log file.\n");
        return 1;
    }


    // Save the original stdout file descriptor
    int stdout_fd = fileno(stdout);

    // Redirect stdout to the log file
    dup2(fileno(log_file), stdout_fd);



    getcwd(cwd, sizeof(cwd));
    printf("cwd %s\n",cwd);

   // Create client socket
    client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket == -1) {
        perror("socket");
        return 1;
    }


    // Set up server address
    struct sockaddr_in server_address;
    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(port_number);
    server_address.sin_addr.s_addr = inet_addr(server_ip);


    // Connect to the server
    if (connect(client_socket, (struct sockaddr*)&server_address, sizeof(server_address)) == -1) {
        perror("connect");
        return 1;
    }





    ssize_t recv_bytes;


        /* code */



    //directorydeki son guncellemeleri gormek icin acabilirsin



    // Receive and process server messages
    char buffer[MESSAGE_SIZE] = {0};




    //monitorDirectory(cwd);
    char number[12] = {0};
    //int value = recv(client_socket, number, sizeof(number),0);

    //printf("value: %d",value);
    //printf("number: %s\n",number);
    //sscanf(number, "%d", &filesth);


    printf("\nCurrent time: %s\n", time_string);


    //printf("filetsh: %d\n",filesth);

    //if( filesth >1){

    while(!flag){
            receiveDirectory(client_socket, cwd);


    }


    

    printf("\n");

     // Flush stdout to ensure it's written immediately
    fflush(stdout);

    // Restore the original stdout file descriptor
    dup2(stdout_fd, fileno(stdout));

    fprintf(stderr,"Writing is Finished\n");
    
        // TODO: Process server messages if needed
        // You can add specific message formats and actions here
    

    // }
        // TODO: Process server messages if needed
        // You can add specific message formats and actions here




    //sendDirectory(client_socket, cwd);

    // Handle server disconnection

    free(prevFiles);

    // Close the log file
    fclose(log_file);

    close(client_socket);

    return 0;
}
