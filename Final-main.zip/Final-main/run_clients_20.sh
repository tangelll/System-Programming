#!/bin/bash

for ((i=1; i<=20; i++))
do
  clientdir="clientdir$i"
  ./client "$clientdir" $1 192.168.1.147 &
done

