#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <time.h>
#include <signal.h>
#include <stdbool.h>
#include <sys/prctl.h>
#define BUFSIZE 256
#define FIFO_PERM (S_IRUSR | S_IWUSR)
#define fifoname1 "fifo1"
#define fifoname2 "fifo2"

/*fun def.*/
int dofifochild(const char *fifoname, const char * fifoname_2);
int dofifochild2(const char *fifoname);
int dofifoparent( const char *fifoname, const char *idstring );
int dofifoparent2( const char *fifoname, const char *idstring );

int sum_add;
int numbers[BUFSIZE] = {0};
int ARRAY_SIZE = 0;
int is_finished = 0;



// Signal handler function for SIGCHLD
void sigchld_handler(int signum) {
    int status;
    pid_t pid;

    // Wait for any child process to terminate
    while ((pid = waitpid(-1, &status, WNOHANG)) > 0) {
        if (WIFEXITED(status)) {
            printf("Child process %d terminated normally with exit status %d.\n", pid, WEXITSTATUS(status));
        } else if (WIFSIGNALED(status)) {
            printf("Child process %d terminated by signal %d.\n", pid, WTERMSIG(status));
        }
    }
}

//PROCEDIN SONLANDIRMAK ICIN
volatile sig_atomic_t child_running = 1;

void sigusr1_handler(int signal) {
    if (signal == SIGUSR1) {


        printf(" Proceding reminated.\n");
        exit(EXIT_SUCCESS);
    }
}


int main(int argc, char *argv[]){
    // SIGCHLD ve SIGUSR1 sinyalleri için sinyal işleyicilerin atanması
    struct sigaction sa;
    sa.sa_flags = SA_RESTART;
    sigemptyset(&sa.sa_mask);
    sa.sa_handler = sigchld_handler;
    if (sigaction(SIGCHLD, &sa, NULL) == -1) {
        perror("sigaction");
        exit(EXIT_FAILURE);
    }

    struct sigaction sp;
    sp.sa_flags = SA_RESTART;
    sigemptyset(&sp.sa_mask);
    sp.sa_handler = sigchld_handler;
    if (sigaction(SIGCHLD, &sp, NULL) == -1) {
        perror("sigaction");
        exit(EXIT_FAILURE);
    }



    //ZOMBI KORUMA
    if (prctl(PR_SET_CHILD_SUBREAPER, 1) == -1) {
        perror("prctl");
        exit(EXIT_FAILURE);
    }


    pid_t childpid1;
    pid_t childpid2;
    pid_t pid;
    int status;
    int counter = 0;
    //TODO ARGV1 KULLANILICAK BIR INT DEGER GIRILICEKK
    if  (argc != 2){
        fprintf(stderr, "Usage: %s int value\n",argv[0]);
        return 1;
    }

    ARRAY_SIZE = atoi(argv[1]);
    //FIRST FIFO
    if  (mkfifo(fifoname1, FIFO_PERM) == -1){
        if (errno != EEXIST){
            fprintf(stderr, "[%ld]: failed to create named pipe %s: %s\n",(long)getpid(), argv[1], strerror(errno));
            return 1;
        }
    }

    //SECOND FIFO
    if  (mkfifo(fifoname2, FIFO_PERM) == -1){
        if (errno != EEXIST){
            fprintf(stderr, "[%ld]: failed to create named pipe %s: %s\n",(long)getpid(), argv[1], strerror(errno));
            return 1;
        }
    }

    //FILL ARRAY
    srand(time(NULL));
    for (int i = 0; i < ARRAY_SIZE; ++i) {
        numbers[i] = rand() % 10 + 1; // 0 ile 10 arasında rastgele sayılar
    }


    //PROCEDING STRING

    if  ((pid= fork()) == -1){
        perror("Failed to fork");
        return 1;
    }
    if ((pid== 0)){

        while (child_running) {
        fprintf(stderr,"proceding\n");
        sleep(2); // Sleep for 2 seconds
     }

    }



    if  ((childpid1 = fork()) == -1){
        perror("Failed to fork");
        return 1;
    }
    if ((childpid1 == 0)){
//ACILACAK        sleep(10);
        sleep(5);
        return dofifochild(fifoname1,fifoname2);
    }else{
        dofifoparent(fifoname1, "this was written by the child to first fifo");
    }    



    
    if  ((childpid2 = fork()) == -1){
        perror("Failed to fork");
        return 1;
    }
    if ((childpid2 == 0)){
//ACILACAK        sleep(10);
        sleep(5);
        return dofifochild2(fifoname2);
    }else{
        //bunu acmadik acmamiz gerekebilir 
        dofifoparent2(fifoname2, "this was written by the child to second fifo");
    }    

    kill(pid, SIGUSR1);
//   Ebeveyn süreç, çocuk süreçlerin bitmesini bekler iki child fifo icin 1 tanesi proceding icin
    for (int i = 0; i < 2; i++) {
        pid_t terminated_pid = wait(&status);
        printf("Child process with PID %d terminated.\n", terminated_pid);
        counter = counter + 2;
        printf("counter: %d\n",counter);
    }

    unlink(fifoname1);
    unlink(fifoname2);

    if (counter == 4){
        printf("Counter equal child num exitting ...\n");
    }
    return 0;
}


int dofifochild2(const char *fifoname_2){
    char  str[10] = {'\0'};
    char multiply_str[10] = {'\0'};
    int multip = 1;
    int fd;
    int rval;

    fprintf(stderr, "[%ld]:(child2) about to open fifo %s...\n",(long)getpid(),fifoname_2);
    while   (((fd = open(fifoname_2,O_RDONLY)) == -1 ) && (errno == EINTR));
    if (fd == -1){
            fprintf(stderr, "[%ld]: failed to open named pipe %s for write: %s\n",(long)getpid(), fifoname_2,strerror(errno));
            return 1;
    }
    rval = read(fd,numbers,sizeof(numbers));
    if (rval ==  -1 ){
        fprintf(stderr, "[%ld]: failed to read from pipe%s\n",(long)getpid(),strerror(errno));
        return 1;
    }
    fprintf(stderr, "[%ld]:(child2) rval: %d bytes read  array from second fifo\n",(long)getpid(),rval);
    
    rval = read(fd,multiply_str,sizeof(multiply_str));
    if (rval ==  -1 ){
        fprintf(stderr, "[%ld]: failed to read from pipe%s\n",(long)getpid(),strerror(errno));
        return 1;
    }
    fprintf(stderr, "[%ld]:(child2) rval: %d bytes read  array from second fifo\n",(long)getpid(),rval);
    


     // String karşılaştırması
    if (strcmp(multiply_str, "multiply") == 0) {
        printf("Carpma işlemi yapılacak...\n");
        // Eğer "multiply" yazıyorsa yapılacak işlemler

        for (size_t i = 0; i < ARRAY_SIZE; i++)
    {
        
        printf("%d, ",numbers[i]);
        multip = multip * numbers[i] ;

    }
    } else {
        printf("Else bloğuna girildi.\n");
        // "multiply" yazmıyorsa yapılacak işlemler
    }

    printf("multiply value: %d\n",multip);

    close(fd);

    while  (((fd = open(fifoname_2, O_RDONLY)) == -1 ) && (errno == EINTR));
    if (fd == -1){
            fprintf(stderr, "[%ld]: failed to open named pipe %s for write: %s\n",(long)getpid(), fifoname_2,strerror(errno));
            return 1;
    }

    rval = read(fd ,str, sizeof(str));
    if( rval != sizeof(str)){
        fprintf(stderr, "[%ld]: failed to write the pipe: %s\n",(long)getpid(),strerror (errno));
        return 1;
    }
    fprintf(stderr, "[%ld]:(child2) rval: %d bytes read  sum in second fifo coming from first child\n",(long)getpid(), rval);
    int sum = atoi(str);
    printf("sum: %d\n",sum);

    sum = sum + multip;
    printf("sum + multiply: %d\n",sum);

    close(fd);




 return 0; 
    
}
int dofifochild(const char *fifoname, const char *fifoname_2){
    char  str[10] = {'\0'};
    int sum =0 ;
    int fd;
    int rval;
    fprintf(stderr, "[%ld]:(child1) about to open FIFO %s...\n",(long)getpid(),fifoname);
    while   (((fd = open(fifoname,O_RDONLY)) == -1 ) && (errno == EINTR));
    if (fd == -1){
            fprintf(stderr, "[%ld]: failed to open named pipe %s for write: %s\n",(long)getpid(), fifoname,strerror(errno));
            return 1;
    }
    rval = read(fd,numbers,sizeof(numbers));
    if (rval ==  -1 ){
        fprintf(stderr, "[%ld]: failed to read from pipe%s\n",(long)getpid(),strerror(errno));
        return 1;
    }
    fprintf(stderr, "[%ld]:(child1) rval: %d bytes read \n",(long)getpid(),rval);


    fprintf(stderr, "[ ");
    for (size_t i = 0; i < ARRAY_SIZE; i++)
    {
        /* code */
        fprintf(stderr, "%d,",numbers[i]);
        sum = sum + numbers[i] ;

    }
    fprintf(stderr, " ]\n");
    
    close(fd);

    fprintf(stderr,"sum value is: %d\n",sum);

    fprintf(stderr, "[%ld]:(child1) about to open second fifo %s...\n",
        (long)getpid(), fifoname_2);

    while  (((fd = open(fifoname_2,O_WRONLY)) == -1 ) && (errno == EINTR));
    if (fd == -1){
            fprintf(stderr, "[%ld]: failed to open named pipe %s for write: %s\n",(long)getpid(), fifoname_2,strerror(errno));
            return 1;
    }

    sprintf(str,"%d",sum);
    printf("Toplama Sounucu:  %s\n",str);
    rval = write(fd ,str, sizeof(str));
    if( rval != sizeof(str)){
        fprintf(stderr, "[%ld]: failed to write the pipe: %s\n",(long)getpid(), strerror(errno));
        return 1;
    }

    fprintf(stderr, "[%ld]:(child1) rval: %d bytes write \n",(long)getpid(),rval);
    sleep(2);
    close(fd);
    
    return 0;
    
}

int dofifoparent2( const char *fifoname_2, const char *idstring){
    char multiply_str[10]="multiply";
    int fd;
    int rval;
    
     fprintf(stderr, "[%ld]:(parent) about to open second fifo %s...\n",
        (long)getpid(), fifoname2);
    while(((fd = open(fifoname2, O_WRONLY)) == -1 ) && (errno == EINTR));
    if (fd == -1){
            fprintf(stderr, "[%ld]: failed to open named pipe %s for write: %s\n",(long)getpid(), fifoname2,strerror(errno));
            return 1;
    }
    fprintf(stderr, "[%ld]:(parent) about to write the array\n",(long)getpid());


    rval = write(fd , numbers, sizeof(numbers));
    if( rval != sizeof(numbers)){
        fprintf(stderr, "[%ld]: failed to write the pipe: %s\n",(long)getpid(), strerror(errno));
        return 1;
    }


    rval = write(fd , multiply_str, sizeof(multiply_str));
    if( rval != sizeof(multiply_str)){
        fprintf(stderr, "[%ld]: failed to write the pipe: %s\n",(long)getpid(), strerror(errno));
        return 1;
    }

    close(fd);



    fprintf(stderr, "[%ld]: finishing ... \n",(long)getpid());
    return 0;
}


int dofifoparent( const char *fifoname, const char *idstring){
    int fd;
    int rval;

    fprintf(stderr, "[%ld]:(parent) about to open fifo %s...\n",
        (long)getpid(), fifoname);
    while(((fd = open(fifoname, O_WRONLY)) == -1 ) && (errno == EINTR));
    if (fd == -1){
            fprintf(stderr, "[%ld]: failed to open named pipe %s for write: %s\n",(long)getpid(), fifoname,strerror(errno));
            return 1;
    }
    fprintf(stderr, "[%ld]:(parent) about to write the array\n",(long)getpid());

    rval = write(fd , numbers, sizeof(numbers));
    if( rval != sizeof(numbers)){
        fprintf(stderr, "[%ld]: failed to write the pipe: %s\n",(long)getpid(), strerror(errno));
        return 1;
    }

    close(fd);
    
   
    

    return 0;
}